# AI Trader v2 — online-ready / PAPER ONLY

Deze versie is voorbereid voor Render.

## Deploy vanaf iPhone

1. Zet deze bestanden in een GitHub-repository:
   - app.py
   - bot.py
   - requirements.txt
   - render.yaml
   - templates/index.html
   - README.md

2. Open Render en verbind GitHub.
3. Kies de repository.
4. Render kan de instellingen uit `render.yaml` gebruiken.

Handmatige instellingen als Render daarom vraagt:
- Runtime: Python
- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn app:app --workers 1 --threads 4 --timeout 120`

## Belangrijk over deze online versie

- Alleen PAPER TRADING.
- Er worden geen echte exchange-orders geplaatst.
- Er zijn geen Binance API keys nodig.
- Marktdata komt via openbare Binance endpoints via CCXT.
- `/health` is toegevoegd voor monitoring.

### Persistente data
De huidige paper-account staat in het geheugen van de server. Bij een restart/redeploy kan de virtuele account dus terugvallen naar €750. Voor een volgende versie kunnen we PostgreSQL/Render Key Value toevoegen zodat trades en instellingen blijven bestaan.

### Gratis Render
Render geeft webservices een publieke HTTPS-URL, maar gratis webservices kunnen na 15 minuten zonder inkomende requests worden stilgezet. Dat maakt de gratis variant ongeschikt als je wilt dat een trading-engine 24/7 zelfstandig blijft draaien. Voor continu paper trading is een permanente service of aparte background worker verstandiger.

## Veiligheid
Voordat echte orders ooit worden toegevoegd:
- authenticatie voor de dashboard;
- server-side secrets;
- database;
- auditlog;
- orderlimieten;
- kill switch;
- rate limits;
- broker/exchange sandbox;
- uitgebreide paper-trading validatie.

Deze app is geen financieel advies en modeluitvoer garandeert geen rendement.
