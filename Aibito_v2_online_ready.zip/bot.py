"""
AI Trading Bot v2 — PAPER TRADING ONLY.

Live public market data is read from Binance through CCXT.
No private API keys are used and no real orders are submitted.

The live signal is a RandomForest probability trained on recent hourly candles.
The paper engine simulates fills, fees, stop-loss and take-profit in memory.
"""

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Dict
import ccxt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

CONFIG = {
    "START_CAPITAL": 750.0,
    "RISK_PER_TRADE": 0.01,
    "MAX_TOTAL_EXPOSURE": 0.80,
    "FEE_RATE": 0.001,
    "STOP_LOSS": 0.03,
    "TAKE_PROFIT": 0.06,
    "BUY_THRESHOLD": 0.58,
    "SELL_THRESHOLD": 0.45,
    "TIMEFRAME": "1h",
    "LIMIT": 600,
    "POLL_SECONDS": 30,
    "MIN_POSITION_EUR": 10.0,
}

SYMBOLS = {
    "BTC": "BTC/USDT",
    "ETH": "ETH/USDT",
    "SOL": "SOL/USDT",
    "XRP": "XRP/USDT",
    "QNT": "QNT/USDT",
}

FEATURES = [
    "ret_1","ret_6","ret_24","sma_12","sma_24","sma_72",
    "macd","macd_signal","rsi","atr_pct","vol_z"
]

@dataclass
class Position:
    symbol: str
    qty: float
    entry: float
    invested: float
    opened_at: str
    probability: float

class PaperEngine:
    def __init__(self):
        self.exchange = ccxt.binance({"enableRateLimit": True, "options": {"defaultType": "spot"}})
        self.running = False
        self.last_error = ""
        self.reset()

    def reset(self):
        self.cash = CONFIG["START_CAPITAL"]
        self.positions: Dict[str, Position] = {}
        self.trades = []
        self.equity_history = []
        self.last_prices = {}
        self.last_signals = {}
        self.last_update = None
        self.last_error = ""

    def update_settings(self, data):
        allowed = {
            "risk_per_trade": ("RISK_PER_TRADE", 0.001, 0.05),
            "max_exposure": ("MAX_TOTAL_EXPOSURE", 0.10, 1.0),
            "stop_loss": ("STOP_LOSS", 0.005, 0.20),
            "take_profit": ("TAKE_PROFIT", 0.005, 0.50),
            "buy_threshold": ("BUY_THRESHOLD", 0.50, 0.90),
            "sell_threshold": ("SELL_THRESHOLD", 0.10, 0.50),
        }
        for key, (cfg, lo, hi) in allowed.items():
            if key in data:
                try:
                    v = float(data[key])
                    CONFIG[cfg] = max(lo, min(hi, v))
                except (TypeError, ValueError):
                    pass

    def fetch_df(self, market):
        rows = self.exchange.fetch_ohlcv(
            market, timeframe=CONFIG["TIMEFRAME"], limit=CONFIG["LIMIT"]
        )
        if not rows:
            raise RuntimeError("Geen marktdata ontvangen")
        d = pd.DataFrame(rows, columns=["timestamp","open","high","low","close","volume"])
        d["timestamp"] = pd.to_datetime(d["timestamp"], unit="ms", utc=True)
        return d

    def features(self, df):
        d = df.copy()
        d["ret_1"] = d["close"].pct_change()
        d["ret_6"] = d["close"].pct_change(6)
        d["ret_24"] = d["close"].pct_change(24)
        d["sma_12"] = d["close"].rolling(12).mean()
        d["sma_24"] = d["close"].rolling(24).mean()
        d["sma_72"] = d["close"].rolling(72).mean()
        d["ema_12"] = d["close"].ewm(span=12, adjust=False).mean()
        d["ema_26"] = d["close"].ewm(span=26, adjust=False).mean()
        d["macd"] = d["ema_12"] - d["ema_26"]
        d["macd_signal"] = d["macd"].ewm(span=9, adjust=False).mean()
        delta = d["close"].diff()
        gain = delta.clip(lower=0).rolling(14).mean()
        loss = (-delta.clip(upper=0)).rolling(14).mean()
        rs = gain / loss.replace(0, np.nan)
        d["rsi"] = 100 - (100 / (1 + rs))
        tr = pd.concat([
            d["high"] - d["low"],
            (d["high"] - d["close"].shift()).abs(),
            (d["low"] - d["close"].shift()).abs()
        ], axis=1).max(axis=1)
        d["atr_pct"] = tr.rolling(14).mean() / d["close"]
        d["vol_z"] = (d["volume"] - d["volume"].rolling(48).mean()) / d["volume"].rolling(48).std()
        d["target"] = (d["close"].shift(-6) > d["close"]).astype(int)
        return d.replace([np.inf, -np.inf], np.nan).dropna()

    def probability(self, df):
        d = self.features(df)
        if len(d) < 250:
            raise RuntimeError("Te weinig bruikbare candles")
        train = d.iloc[:-1]
        latest = d.iloc[[-1]]
        model = RandomForestClassifier(
            n_estimators=180, max_depth=7, min_samples_leaf=8,
            random_state=42, class_weight="balanced_subsample", n_jobs=-1
        )
        model.fit(train[FEATURES], train["target"])
        return float(model.predict_proba(latest[FEATURES])[:,1][0]), float(latest["close"].iloc[0])

    def portfolio_value(self):
        return self.cash + sum(
            p.qty * self.last_prices.get(sym, p.entry)
            for sym, p in self.positions.items()
        )

    def exposure(self):
        return sum(
            p.qty * self.last_prices.get(sym, p.entry)
            for sym, p in self.positions.items()
        )

    def execute_sell(self, sym, px, reason):
        p = self.positions.pop(sym)
        gross = p.qty * px
        fee = gross * CONFIG["FEE_RATE"]
        pnl = (px - p.entry) * p.qty - fee - p.invested * CONFIG["FEE_RATE"]
        self.cash += gross - fee
        self.trades.append({
            "time": datetime.now(timezone.utc).isoformat(),
            "symbol": sym, "side": "SELL", "price": px,
            "value": gross, "pnl": pnl, "reason": reason
        })

    def step(self):
        signals = {}
        prices = {}
        errors = []
        for sym, market in SYMBOLS.items():
            try:
                df = self.fetch_df(market)
                prob, px = self.probability(df)
                signals[sym] = prob
                prices[sym] = px
            except Exception as exc:
                errors.append(f"{sym}: {exc}")

        if not prices:
            self.last_error = "; ".join(errors) or "Geen data"
            return self.snapshot()

        self.last_prices.update(prices)
        self.last_signals.update(signals)

        # Manage existing paper positions.
        for sym in list(self.positions):
            if sym not in prices:
                continue
            p = self.positions[sym]
            px = prices[sym]
            prob = signals.get(sym, 0.0)
            if px <= p.entry * (1 - CONFIG["STOP_LOSS"]):
                self.execute_sell(sym, px, "stop_loss")
            elif px >= p.entry * (1 + CONFIG["TAKE_PROFIT"]):
                self.execute_sell(sym, px, "take_profit")
            elif prob < CONFIG["SELL_THRESHOLD"]:
                self.execute_sell(sym, px, "ai_exit")

        # New entries: strongest probabilities first.
        equity = self.portfolio_value()
        room = max(0.0, equity * CONFIG["MAX_TOTAL_EXPOSURE"] - self.exposure())
        candidates = sorted(
            [(s,p) for s,p in signals.items()
             if p >= CONFIG["BUY_THRESHOLD"] and s not in self.positions],
            key=lambda x: x[1], reverse=True
        )
        for sym, prob in candidates:
            if room < CONFIG["MIN_POSITION_EUR"]:
                break
            risk_budget = equity * CONFIG["RISK_PER_TRADE"]
            value = min(risk_budget / CONFIG["STOP_LOSS"], room, self.cash / (1 + CONFIG["FEE_RATE"]))
            if value < CONFIG["MIN_POSITION_EUR"]:
                continue
            px = prices[sym]
            qty = value / px
            fee = value * CONFIG["FEE_RATE"]
            self.cash -= value + fee
            self.positions[sym] = Position(
                sym, qty, px, value,
                datetime.now(timezone.utc).isoformat(), prob
            )
            room -= value
            self.trades.append({
                "time": datetime.now(timezone.utc).isoformat(),
                "symbol": sym, "side": "BUY", "price": px,
                "value": value, "pnl": 0.0,
                "reason": f"AI {prob:.1%}"
            })

        equity = self.portfolio_value()
        self.equity_history.append({
            "time": datetime.now(timezone.utc).isoformat(),
            "equity": equity
        })
        self.equity_history = self.equity_history[-240:]
        self.last_update = datetime.now(timezone.utc).isoformat()
        self.last_error = "; ".join(errors)
        return self.snapshot()

    def snapshot(self):
        equity = self.portfolio_value()
        start = CONFIG["START_CAPITAL"]
        curve = [x["equity"] for x in self.equity_history] or [start]
        peak = max(curve)
        dd = curve[-1] / peak - 1 if peak else 0
        realized = sum(t["pnl"] for t in self.trades if t["side"] == "SELL")
        return {
            "running": self.running,
            "cash": round(self.cash, 2),
            "equity": round(equity, 2),
            "pnl": round(equity - start, 2),
            "return_pct": round((equity / start - 1) * 100, 2),
            "drawdown_pct": round(dd * 100, 2),
            "realized_pnl": round(realized, 2),
            "prices": self.last_prices,
            "signals": self.last_signals,
            "positions": [asdict(p) for p in self.positions.values()],
            "trades": self.trades[-30:][::-1],
            "equity_history": self.equity_history[-120:],
            "last_update": self.last_update,
            "error": self.last_error,
            "settings": {
                "risk_per_trade": CONFIG["RISK_PER_TRADE"],
                "max_exposure": CONFIG["MAX_TOTAL_EXPOSURE"],
                "stop_loss": CONFIG["STOP_LOSS"],
                "take_profit": CONFIG["TAKE_PROFIT"],
                "buy_threshold": CONFIG["BUY_THRESHOLD"],
                "sell_threshold": CONFIG["SELL_THRESHOLD"],
            }
        }
